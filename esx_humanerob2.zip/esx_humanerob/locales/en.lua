Locales['en'] = {

	['robbery_cancelled'] = 'Ryöstö epäonnistui, et saanut mitään. Nyt, pakene!',
	['robbery_successful'] = 'Ryöstö onnistui, varastit ~g~$.',
	['press_to_rob'] = 'Paina ~INPUT_CONTEXT~ ryöstääksesi ~r~',
	['robbery_of'] = 'Ryöstetään labraa: ~r~',
	['seconds_remaining'] = '~w~ sekuntia',
	['robbery_cancelled_at'] = '~r~ Humane Labs ryöstö peruuntui: ~b~',
	['robbery_has_cancelled'] = '~r~ Humane Labs ryöstö peruuntui: ~b~',
	['already_robbed'] = 'labra on ryöstetty, odota vielä :',
	['seconds'] = 'sekuntia.',
	['rob_in_prog'] = '~r~ Ryöstö käynnissä: ~b~',
	['started_to_rob'] = 'Aloitit ryöstön ',
	['do_not_move'] = ', Älä liiku!',
	['alarm_triggered'] = 'Hälytys laukaistu.',
	['hold_pos'] = 'Pysy tässä 10MIN ajan ja saalis on sinun!',
	['robbery_complete'] = '~r~ Sinä onnistuit ryöstössä.~s~ ~h~ Juokse!',
	['robbery_complete_at'] = '~r~ Ryöstö valmis kohteessa: ~b~',
	['min_two_police'] = 'Poliiseja vaaditaan: ',
	['robbery_already'] = '~r~Ryöstö on jo käynnissä.',
	-- HAKKEROINTI
	['haxyes'] = 'Hakkerointi ~g~onnistui! ~w~Siirry seuraavaan pisteeseen.',
	['haxyes'] = 'Hakkerointi ~r~epäonnistui! ~w~Tämä reissu oli tässä.',

	-- RYÖSTÄJÄLLE HOMMIA:DD			#1
	['kolistele'] = 'Paina ~INPUT_CONTEXT~ hakataksesi ovea, oven raosta saattaisit saada jotakin...',
	['tyhjapaperi'] = 'Oho, oven raosta leijaili paperi, mutta se on tyhjä!',
	['saitmoran'] = '~r~SIIS MITÄ?! ~w~SINÄ SAIT PUUKON!',
	['saitsilun'] = '~r~SIIS MITÄ?! ~w~SINÄ SAIT SILUN!',
	['eipaollu'] = 'Et löytänyt mitään, koita vielä...',
	-- JATKUU RYÖSTÄJÄN HOMMAT MUTTA NYT ON PESU  #2
	['saitlikasta'] = 'Sinä sait likaista rahaa.',
}
