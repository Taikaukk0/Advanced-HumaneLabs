local holdingup = false
local bank = ""
local secondsRemaining = 0
local blipRobbery = nil
ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

function DisplayHelpText(str)
	SetTextComponentFormat("STRING")
	AddTextComponentString(str)
	DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end

function drawTxt(x,y ,width,height,scale, text, r,g,b,a, outline)
    SetTextFont(0)
    SetTextProportional(0)
    SetTextScale(scale, scale)
    SetTextColour(r, g, b, a)
    SetTextDropShadow(0, 0, 0, 0,255)
    SetTextEdge(1, 0, 0, 0, 255)
    SetTextDropShadow()
    if(outline)then
	    SetTextOutline()
	end
    SetTextEntry("STRING")
    AddTextComponentString(text)
	DrawText(x - width/1.530, y - height/0.75)
end

RegisterNetEvent('esx_humanerob:currentlyrobbing')
AddEventHandler('esx_humanerob:currentlyrobbing', function(robb)
	holdingup = true
	bank = robb
	secondsRemaining = 600
end)

RegisterNetEvent('esx_humanerob:killblip')
AddEventHandler('esx_humanerob:killblip', function()
    RemoveBlip(blipRobbery)
end)

RegisterNetEvent('esx_humanerob:setblip')
AddEventHandler('esx_humanerob:setblip', function(position)
    blipRobbery = AddBlipForCoord(position.x, position.y, position.z)
    SetBlipSprite(blipRobbery , 161)
    SetBlipScale(blipRobbery , 3.1)
    SetBlipColour(blipRobbery, 1)
    PulseBlip(blipRobbery)
end)

RegisterNetEvent('esx_humanerob:toofarlocal')
AddEventHandler('esx_humanerob:toofarlocal', function(robb)
	holdingup = false
	ESX.ShowNotification(_U('robbery_cancelled'))
	robbingName = ""
	secondsRemaining = 0
	incircle = false
end)


RegisterNetEvent('esx_humanerob:robberycomplete')
AddEventHandler('esx_humanerob:robberycomplete', function(robb)
	holdingup = false
	ESX.ShowNotification(_U('robbery_complete') .. Banks[bank].reward)
	bank = ""
	secondsRemaining = 0
	incircle = false
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if holdingup then
			Citizen.Wait(1000)
			if(secondsRemaining > 0)then
				secondsRemaining = secondsRemaining - 1
			end
		end
	end
end)

incircle = false

Citizen.CreateThread(function()
	while true do
		local pos = GetEntityCoords(GetPlayerPed(-1), true)

		for k,v in pairs(Banks)do
			local pos2 = v.position

			if(Vdist(pos.x, pos.y, pos.z, pos2.x, pos2.y, pos2.z) < 15.0)then
				if not holdingup then
					DrawMarker(27, v.position.x, v.position.y, v.position.z - 1, 0, 0, 0, 0, 0, 0, 1.0001, 1.0001, 1.5001, 1555, 0, 0,255, 0, 0, 0,0)

					if(Vdist(pos.x, pos.y, pos.z, pos2.x, pos2.y, pos2.z) < 1.0)then
						if (incircle == false) then
							DisplayHelpText(_U('press_to_rob') .. v.nameofbank)
						end
						incircle = true
						if IsControlJustReleased(1, 51) then
							TriggerClientEvent('esx:showNotification', xPlayers[i], _U('rob_in_prog') .. bank.nameofbank)
							TriggerEvent('esx_humanerob:setblip', xPlayers[i], Banks[robb].position)
							TriggerServerEvent('esx_humanerob:rob', k)
							TriggerEvent("utk_fingerprint:Start", 4, 1, 4, function(outcome, reason)
								if outcome == false then
									ESX.ShowNotification("Hävisit hakkeroinnin")
									TriggerEvent("esx_humanerob:toofarlocal")
									holdingup = false
								elseif outcome == true then
									ESX.ShowNotification("Voitit hakkeroinnin")
								end
							end
						end
					elseif(Vdist(pos.x, pos.y, pos.z, pos2.x, pos2.y, pos2.z) > 1.0)then
						incircle = false
					end
				end
			end
		end

		if holdingup then
			local pos = GetEntityCoords(GetPlayerPed(-1), true)
			for k,v in pairs(Banks)do
				local pos3 = v.kolistele
				local teki1 = false
				if(Vdist(pos.x, pos.y, pos.z, pos3.x, pos3.y, pos3.z) < 15.0)then
					DrawMarker(27, v.kolistele.x, v.kolistele.y, v.kolistele.z - 1, 0, 0, 0, 0, 0, 0, 1.0001, 1.0001, 1.5001, 1555, 0, 0,255, 140, 0, 0,0)

					if(Vdist(pos.x, pos.y, pos.z, pos3.x, pos3.y, pos3.z) < 1.0)then
						if (incircle == false) then
							DisplayHelpText(_U('kolistele'))
						else
							teki1 = false
						end
						incircle = true
						if IsControlJustReleased(1, 51) then
							if not teki1 then
								TriggerEvent("esx_humanerob:kolistele", function()
									Citizen.wait(34000)
									teki1 = true
								end)
							else
								ESX.ShowNotification("Olet tehnyt tämän tehtävän jo!")
							end
						end
					elseif(Vdist(pos.x, pos.y, pos.z, pos3.x, pos3.y, pos3.z) > 1.0)then
						incircle = false
					end

					drawTxt(0.66, 1.44, 1.0,1.0,0.4, _U('robbery_of') .. secondsRemaining .. _U('seconds_remaining'), 255, 255, 255, 255)

					local pos2 = Banks[bank].position

					if(Vdist(pos.x, pos.y, pos.z, pos2.x, pos2.y, pos2.z) > 9.7)then
						TriggerServerEvent('esx_humanerob:toofar', bank)
					end
				end
			end
		end
	end
end)


-- MUISTITIKKU22

RegisterNetEvent('esx_humanerob:aloitahack')
AddEventHandler('esx_humanerob:aloitahack', function(source)
	Citizen.Wait(1000)
	ExecuteCommand( "e tablet2" )
end)


-- TEHTÄVÄT

RegisterNetEvent('esx_humanerob:kolistele') -- TEHTÄVÄ 
AddEventHandler('esx_humanerob:kolistele', function()
	ExecuteCommand( "e knock2" )
	tehtavapalkki()
	Citizen.Wait(1000)
	TriggerServerEvent('esx_humanerob:kolistelupalkkio')
	Citizen.Wait(10000)
	TriggerServerEvent('esx_humanerob:kolistelupalkkio')
	Citizen.Wait(10000)
	TriggerServerEvent('esx_humanerob:kolistelupalkkio')
	ClearPedTasksImmediately(GetPlayerPed(-1))
	ESX.ShowNotification("Katsotaas mitä täältä löytyi... (Avaa inventory niin näet.)")
end)


function tehtavapalkki()
	TriggerEvent("mythic_progbar:client:progress", {
        name = "unique_action_name",
        duration = 30200,
        label = "Tehdään tehtävää...",
        useWhileDead = false,
        canCancel = false,
        controlDisables = {
            disableMovement = true,
            disableCarMovement = true,
            disableMouse = false,
            disableCombat = true,
        }
    }, function(status)
        if not status then
        end
	end)
end