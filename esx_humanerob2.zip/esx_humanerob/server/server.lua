local rob = false
local robbers = {}
ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

function get3DDistance(x1, y1, z1, x2, y2, z2)
	return math.sqrt(math.pow(x1 - x2, 2) + math.pow(y1 - y2, 2) + math.pow(z1 - z2, 2))
end

RegisterServerEvent('esx_humanerob:toofar')
AddEventHandler('esx_humanerob:toofar', function(robb)
	local source = source
	local xPlayers = ESX.GetPlayers()
	rob = false
	for i=1, #xPlayers, 1 do
 		local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
 		if xPlayer.job.name == 'police' then
			TriggerClientEvent('esx:showNotification', xPlayers[i], _U('robbery_cancelled_at') .. Banks[robb].nameofbank)
			TriggerClientEvent('esx_humanerob:killblip', xPlayers[i])
		end
	end
	if(robbers[source])then
		TriggerClientEvent('esx_humanerob:toofarlocal', source)
		robbers[source] = nil
		TriggerClientEvent('esx:showNotification', source, _U('robbery_has_cancelled') .. Banks[robb].nameofbank)
	end
end)

RegisterServerEvent('esx_humanerob:rob')
AddEventHandler('esx_humanerob:rob', function(robb)

	local source = source
	local xPlayer = ESX.GetPlayerFromId(source)
	local stikki22 = xPlayer.getInventoryItem('stikki22')
	local xPlayers = ESX.GetPlayers()
	
	if Banks[robb] then

		local bank = Banks[robb]

		if (os.time() - bank.lastrobbed) < 43200 and bank.lastrobbed ~= 0 then

			TriggerClientEvent('esx:showNotification', source, _U('already_robbed') .. (2 - (os.time() - bank.lastrobbed)) .. _U('seconds'))
			return
		end


		local cops = 0
		for i=1, #xPlayers, 1 do
 		local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
 		if xPlayer.job.name == 'police' then
				cops = cops + 1
			end
		end


		if rob == false then
		   
		  if xPlayer.getInventoryItem('stikki22').count >= 1 then
		     xPlayer.removeInventoryItem('stikki22', 1)

			if(cops >= Config.NumberOfCopsRequired)then

				rob = true
				for i=1, #xPlayers, 1 do
					local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
					if xPlayer.job.name == 'police' then
						ESX.ShowNotification("Ryöstön hakkerointi on läpäisty! Mene paikalle pysäyttämään ryöstö.")
					end
				end

				TriggerClientEvent('esx:showNotification', source, _U('started_to_rob') .. bank.nameofbank .. _U('do_not_move'))
				TriggerClientEvent('esx:showNotification', source, _U('alarm_triggered'))
				TriggerClientEvent('esx:showNotification', source, _U('hold_pos'))
				TriggerClientEvent('esx_humanerob:aloitahack', source)
				TriggerClientEvent('esx_humanerob:currentlyrobbing', source, robb)
				Banks[robb].lastrobbed = os.time()
				robbers[source] = robb
				local savedSource = source
				SetTimeout(600000, function()

					if(robbers[savedSource])then

						rob = false
						TriggerClientEvent('esx_humanerob:robberycomplete', savedSource, job)
						if(xPlayer)then

							xPlayer.addAccountMoney('black_money', bank.reward)
							local xPlayers = ESX.GetPlayers()
							for i=1, #xPlayers, 1 do
								local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
								if xPlayer.job.name == 'police' then
										TriggerClientEvent('esx:showNotification', xPlayers[i], _U('robbery_complete_at') .. bank.nameofbank)
										TriggerClientEvent('esx_humanerob:killblip', xPlayers[i])
								end
							end
						end
					end
				end)
			else
				TriggerClientEvent('esx:showNotification', source, _U('min_two_police') .. Config.NumberOfCopsRequired)
			end
		end
		else
			TriggerClientEvent('esx:showNotification', source, _U('robbery_already'))
		end
	end
end)

-- MUISTITIKKU22

ESX.RegisterUsableItem('stikki22', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    local stikki22 = xPlayer.getInventoryItem('stikki22')

    xPlayer.removeInventoryItem('stikki22', 1)
    TriggerClientEvent('esx_humanerob:aloitahack', source)
end)

-- KOLISTELU PALKKIO  

RegisterServerEvent('esx_humanerob:kolistelupalkkio')
AddEventHandler('esx_humanerob:kolistelupalkkio', function()
	local xPlayer = ESX.GetPlayerFromId(source)
	local hokale = math.random(1,7)
	local random22 = math.random(400,1500)

	if hokale == 1 then
		xPlayer.addAccountMoney('black_money', random22)
		TriggerClientEvent('esx:showNotification', source, _U('saitlikasta') .. random22)
	elseif hokale == 2 then
		TriggerClientEvent('esx:showNotification', source, _U('tyhjapaperi'))
	elseif hokale == 3 then
		xPlayer.addWeapon('WEAPON_SWITCHBLADE')
		TriggerClientEvent('esx:showNotification', source, _U('saitmoran'))
	elseif hokale == 4 then
		xPlayer.addAccountMoney('black_money', random22)
		TriggerClientEvent('esx:showNotification', source, _U('saitlikasta') .. random22)
	elseif hokale == 5 then
		xPlayer.addAccountMoney('black_money', random22)
		TriggerClientEvent('esx:showNotification', source, _U('saitlikasta') .. random22)
	elseif hokale == 6 then
		xPlayer.addInventoryItem('silu', 1)
		TriggerClientEvent('esx:showNotification', source, _U('saitsilun'))
	elseif hokale == 7 then
		TriggerClientEvent('esx:showNotification', source, _U('tyhjapaperi'))
	else
		TriggerClientEvent('esx:showNotification', source, _U('eipaollu'))
	end
end)
