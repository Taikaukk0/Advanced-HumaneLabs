Config = {}
Config.Locale = 'en'
Config.NumberOfCopsRequired = 0

Banks = {
	["humane_labs"] = {
		position = { ['x'] = 3536.17, ['y'] = 3660.11, ['z'] = 28.12 }, -- Ryöstön Aloitus #0
		kolistele = { ['x'] = 3541.5, ['y'] = 3667.59, ['z'] = 28.12 }, -- Minigame kun ryöstät #1
		pesemassit = { ['x'] = 3533.5, ['y'] = 3661.96, ['z'] = 28.12 }, -- Minigame kun ryöstät #1
		reward = math.random(400000,1300000),
		nameofbank = "Labra",
		lastrobbed = 0
	},
}
